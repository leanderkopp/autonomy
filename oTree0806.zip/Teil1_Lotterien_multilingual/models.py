from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


authors = 'Jana Freundt, Leander Kopp, University of Fribourg'

doc = """
Autonomy PET based on the staircase price list in Falk et al's GPS
Part 1: choices between lotteries to reveal lotteries between which a participant is indifferent
Part 2: WTP to decide or to buy decision right
Part 3: questionnaire with socio-demogr. and aut survey questions
"""


class Constants(BaseConstants):
    name_in_url = 'Teil1_en'
    players_per_group = None
    num_rounds = 1
    #set the language of the experiment **** Note: for English type 'english' for german change to 'german', doing it with capital letters WON'T work
    language = 'english'
    #language = 'german'

    endowment = c(10)
    #set payoff for lotteries. Note: If we are working with lists (to make a double random draw afterwards (random draw out of pool of decisions about lotteries, random draw to generate payoff)
    # therefore also safe options (e.g. sure payment of 3$ needs to have a "lottery" data structure --> surepayment= [3.3]
    # set payoff for lottery B (risky option)
    lotteryB = [3,0]
    #the following variables will not be needed, if we work with lists
    #should we use currency (c(amount)) or not? are there advantages?
    # doesnt matter at all
    lotteryA_high_payoff = 3
    lotteryA_low_payoff = 0
    lotteryA_prob = 0.5
    #set payoffs for lottery A (safe option)
    lottery_r1A= [1.6,0]
    lottery_r2A = [0.8,0]
    lottery_r3A = [0.4,0]
    lottery_r4A = [0.6,0]
    lottery_r5A = [0.7,0]
    lottery_r6A = [0.5,0]
    lottery_r7A = [0.2,0]
    lottery_r8A = [0.3,0]
    lottery_r9A = [0.1,0]
    lottery_r10A = [1.2,0]
    lottery_r11A = [1.0,0]
    lottery_r12A = [0.9,0]
    lottery_r13A = [1.1,0]
    lottery_r14A = [1.4,0]
    lottery_r15A = [1.5,0]
    lottery_r16A = [1.3,0]
    lottery_r17A = [2.4,0]
    lottery_r18A = [2.0,0]
    lottery_r19A = [1.8,0]
    lottery_r20A = [1.9,0]
    lottery_r21A = [1.7,0]
    lottery_r22A = [2.2,0]
    lottery_r23A = [2.3,0]
    lottery_r24A = [2.1,0]
    lottery_r25A = [2.8,0]
    lottery_r26A = [2.6,0]
    lottery_r27A = [2.7,0]
    lottery_r28A = [2.5,0]
    lottery_r29A = [3.0,0]
    lottery_r30A = [2.9,0]
    lottery_r31A = [3.1,0]



    pass


#class Participant(BaseParticipant):

# pass

class Subsession(BaseSubsession):

    pass


class Group(BaseGroup):

    pass


class Player(BasePlayer):
    #Risk Category
    riskc = models.FloatField(initial=1)
    #LotteryB: risky option, doesn't change, will always be constant
    lotteryB_high = models.FloatField(initial=9) #define high value of lottery_B here
    lotteryB_low = models.FloatField(initial=4.5) #define low value of lotteryB here
    lotteryB_probability_high = models.FloatField(initial=50)
    #LotteryA: safe option, will change depending on player's decision in the staircase
    # (e.g. if lottery A (1.6 for sure) is preferred over lottery b (3 50% chance, 0 50% chance), then lottery A will be lower in the next stage
    lotteryA = models.FloatField(initial=8) #define initial value here
    lotteryA_high = models.FloatField(initial=8)
    lotteryA_low = models.FloatField(initial=3)
    lotteryA_probability_high = models.FloatField(initial=75)
    #Practice Lottery Variable
    practicelottery_DrawsA = models.FloatField(blank=True)
    practicelottery_DrawsB = models.FloatField(blank=True)
    practicelottery_probA = models.FloatField(blank=True)
    practicelottery_probB = models.FloatField(blank=True)

    chosen_lottery = models.StringField()
    #Payout variable
    lottery_outcome = models.FloatField()
    #Booleans for Decisions for Staircase Tree
    staircase1_GPSrisk=models.BooleanField()
    staircase2_GPSrisk=models.BooleanField()
    staircase3_GPSrisk=models.BooleanField()
    staircase4_GPSrisk=models.BooleanField()
    staircase5_GPSrisk=models.BooleanField()

    ControlQuestion1 = models.IntegerField()
    ControlQuestion2 = models.IntegerField()
    ControlQuestion3 = models.IntegerField()
    ControlQuestion4 = models.IntegerField()
    ControlQuestion5 = models.IntegerField()
    ControlQuestion6 = models.IntegerField()



    #counter for control questions
    counterWrong = models.IntegerField(initial=0)


    ################# OLD CODE
    #define payoff-variable (we could also just work with the predefined variable player.payoff)
    # sure
    payoff_lotteries = models.FloatField()
    prob= models.StringField()
    quiz = models.IntegerField(
        choices=[
            [True, '50%'],
            [False, '25%'],
            [False, '15%'],
        ]
    )


    GPSfocus = models.FloatField(blank=True)
    GPSunfocus = models.FloatField(blank=True)
    GPSfocusevent = models.FloatField(blank=True)
    GPSvisibevent = models.FloatField(blank=True)
    #Time-Variables

    time_part1_instructions = models.FloatField()
    time_part1_instructions_unfocus = models.FloatField()
    time_part1_staircases = models.FloatField()
    time_part1_staircases_unfocus = models.FloatField()

    pass


