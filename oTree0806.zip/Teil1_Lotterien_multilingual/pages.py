from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import random
#from otree_tools.utils import get_focused_time, get_unfocused_time, get_time_per_page, num_focusoff_events


class Intro_Title(Page):
    pass


class Announce_Choice(Page):
    pass

class Instructions_Consent(Page):
    pass

class Instructions_General(Page):
    def before_next_page(self):
        self.participant.vars['choicenumber']=1
        self.participant.label = str(self.player.id_in_group)

class Description_Lotteries(Page):
    pass

class ControlQuestions(Page):
    form_model = 'player'
    form_fields = ['ControlQuestion1', 'ControlQuestion2', 'ControlQuestion3','ControlQuestion4','ControlQuestion5','ControlQuestion6','counterWrong']


class Staircase1(Page):
    form_model = 'player'
    form_fields = ['staircase1_GPSrisk']

    def before_next_page(self):
        self.participant.vars['decisions_GPSrisk'] = list() # define list of subjects decision
        if self.player.staircase1_GPSrisk==True: #if player prefers Lottery B
            self.participant.vars['decisions_GPSrisk'].append([True, self.player.lotteryB_high, self.player.lotteryB_low,1]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high+= -1.60 #since player prefers Lottery B, Lottery B will be lower in the next stage.
            self.player.lotteryB_low += 0.80  # since player prefers Lottery B, Lottery B will be lower in the next stage.
        elif self.player.staircase1_GPSrisk==False: #if player prefers Lottery A
            self.participant.vars['decisions_GPSrisk'].append([False, self.player.lotteryB_high, self.player.lotteryB_low,1]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high+= 1.60 #since player prefers Lottery A, lotteryB will be higher in the next stage.
            self.player.lotteryB_low += -0.80  # since player prefers Lottery A, lotteryB will be higher in the next stage.

        self.participant.vars['choicenumber'] +=1
class Staircase2(Page):
    form_model = 'player'
    form_fields = ['staircase2_GPSrisk']

    def before_next_page(self):
        if self.player.staircase2_GPSrisk==True: #if player prefers Lottery B
            self.participant.vars['decisions_GPSrisk'].append([True, self.player.lotteryB_high, self.player.lotteryB_low,2]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high+= -0.80 #since player prefers Lottery B, Lottery B will be lower in the next stage.
            self.player.lotteryB_low += 0.40  # since player prefers Lottery B, Lottery B will be lower in the next stage.
        elif self.player.staircase2_GPSrisk==False: #if player prefers Lottery A
            self.participant.vars['decisions_GPSrisk'].append([False, self.player.lotteryB_high, self.player.lotteryB_low,2]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high += 0.80  # since player prefers Lottery A, lotteryB will be higher in the next stage.
            self.player.lotteryB_low += -0.40  # since player prefers Lottery A, lotteryB will be higher in the next stage.

        self.participant.vars['choicenumber'] += 1

class Staircase3(Page):
    form_model = 'player'
    form_fields = ['staircase3_GPSrisk']

    def before_next_page(self):
        if self.player.staircase3_GPSrisk==True: #if player prefers Lottery B
            self.participant.vars['decisions_GPSrisk'].append([True, self.player.lotteryB_high, self.player.lotteryB_low,3]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high+= -0.40 #since player prefers Lottery B, Lottery B will be lower in the next stage.
            self.player.lotteryB_low += 0.20  # since player prefers Lottery B, Lottery B will be lower in the next stage.
        elif self.player.staircase3_GPSrisk==False: #if player prefers Lottery A
            self.participant.vars['decisions_GPSrisk'].append([False, self.player.lotteryB_high, self.player.lotteryB_low,3]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high += 0.40  # since player prefers Lottery A, lotteryB will be higher in the next stage.
            self.player.lotteryB_low += -0.20  # since player prefers Lottery A, lotteryB will be higher in the next stage.

        self.participant.vars['choicenumber'] += 1

class Staircase4(Page):
    form_model = 'player'
    form_fields = ['staircase4_GPSrisk']

    def before_next_page(self):
        if self.player.staircase4_GPSrisk==True: #if player prefers Lottery B
            self.participant.vars['decisions_GPSrisk'].append([True, self.player.lotteryB_high, self.player.lotteryB_low,4]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high+= -0.20 #since player prefers Lottery B, Lottery B will be lower in the next stage.
            self.player.lotteryB_low += 0.10  # since player prefers Lottery B, Lottery B will be lower in the next stage.
        elif self.player.staircase4_GPSrisk==False: #if player prefers Lottery A
            self.participant.vars['decisions_GPSrisk'].append([False, self.player.lotteryB_high, self.player.lotteryB_low,4]) #save decision for Lottery A in 'decisions_GPSRisk'
            self.player.lotteryB_high += 0.20  # since player prefers Lottery A, lotteryB will be higher in the next stage.
            self.player.lotteryB_low += -0.10  # since player prefers Lottery A, lotteryB will be higher in the next stage.

        self.participant.vars['choicenumber'] += 1

class Staircase5(Page):
    form_model = 'player'
    form_fields = ['staircase5_GPSrisk']

    def before_next_page(self):
        if self.player.staircase5_GPSrisk==True: #if player prefers Lottery B
            self.participant.vars['decisions_GPSrisk'].append([True, self.player.lotteryB_high, self.player.lotteryB_low,5]) #save decision for Lottery A in 'decisions_GPSRisk'
            #self.player.lotteryA+=0.10 #since player prefers Lottery B, Lottery A will be higher in the next stage.
        elif self.player.staircase5_GPSrisk==False: #if player prefers Lottery A
            self.participant.vars['decisions_GPSrisk'].append([False, self.player.lotteryB_high, self.player.lotteryB_low,5]) #save decision for Lottery A in 'decisions_GPSRisk'
            #self.player.lotteryA+=-0.10 #since player prefers Lottery A, lotteryA will be lower in the next stage.

        #make random draw for payout
        random_decision = random.choice(self.participant.vars['decisions_GPSrisk'])
        print("random choice:", random_decision)
        if random_decision[0] == True:
            self.player.chosen_lottery = "Lottery B"
            #self.player.lottery_outcome = random.choice([self.player.lotteryB_high,self.player.lotteryB_low])
            #self.player.lottery_outcome = random.choice(random_decision[1],random_decision[2])
            random_draw=random.choice(range(0,100)) #random draw out of integers from 0 to 99
            if random_draw<self.player.lotteryB_probability_high: # if the chosen number is smaller than the probability of the high outcome of lotteryB, the high outcome of lotteryB is chosen
                self.player.lottery_outcome = random_decision[1] #lotteryB_high_outcome is chosen in 50 cases
            else:
                self.player.lottery_outcome = random_decision[2]  # lotteryB_low_outcome is chosen in 50 cases
        elif random_decision[0] == False:
            self.player.chosen_lottery="Lottery A"
            random_draw=random.choice(range(0,100)) #random draw out of integers from 0 to 99
            if random_draw < self.player.lotteryA_probability_high: # if the chosen number is smaller than the probability of the high outcome of lotteryA, the high outcome of lotteryA is chosen
                self.player.lottery_outcome = self.player.lotteryA_high #lotteryA_high_outcome is chosen in 75 cases
            else:
                self.player.lottery_outcome = self.player.lotteryA_low #LotteryA_low is chosen as outcome in 25 cases

        print("auszahlung:",self.player.lottery_outcome)
        # define riskcatergory according to staircase-payout-structure
        self.player.riskc=(self.participant.vars['decisions_GPSrisk'][4][1]/0.2)-28-self.participant.vars['decisions_GPSrisk'][4][0]
        print("riskc",self.player.riskc)
        self.participant.vars['risk_category']=self.player.riskc #prepare risk_category for part II
        # prepare payout-information for part II & III

        self.participant.vars['payout_part1']= self.player.lottery_outcome
        self.participant.vars['lottery_part1']=random_decision[0] # if true, lottery B was chosen, if false, lottery A was chosen
        self.participant.vars['situation_part1']=random_decision[3] # store random selected situation

class PracticeLottery(Page):
    form_model = 'player'
    form_fields = ['practicelottery_DrawsA','practicelottery_DrawsB', 'practicelottery_probA', 'practicelottery_probB']


class Riskresult(Page):
    pass
    #def before_next_page(self):
        #pages_instructions = ['Instructions_General', 'Description_Lotteries', 'ControlQuestions', 'ControlQuestions']
        #pages_staircases =['Staircase1', 'Staircase2', 'Staircase3', 'Staircase4', 'Staircase5']

        #self.player.time_part1_instructions = sum([get_time_per_page(self.player, i) for i in pages_instructions])
        #self.player.time_part1_instructions_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_instructions]) #- self.player.time_part1_instructions

        #self.player.time_part1_staircases = sum([get_time_per_page(self.player, i) for i in pages_staircases])
        #self.player.time_part1_staircases_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_staircases]) #- self.player.time_part1_staircases






page_sequence = [
    #Instructions_Consent,
    Instructions_General,
    Intro_Title,
    Description_Lotteries,
    #ControlQuestions,
    PracticeLottery,
    Announce_Choice,Staircase1,
    Announce_Choice,Staircase2,
    Announce_Choice,Staircase3,
    Announce_Choice,Staircase4,
    Announce_Choice,Staircase5,
    Riskresult]
