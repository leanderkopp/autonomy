from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
from .models import Constants
import random

class PlayerBot(Bot):

    def play_round(self):

        yield pages.Instructions_General
        yield pages.Description_Lotteries
        yield (pages.ControlQuestions, {'ControlQuestion1': 1, 'ControlQuestion2': 0, 'ControlQuestion3': 1,'ControlQuestion4': 0,'ControlQuestion5':1,'ControlQuestion6':1,'counterWrong':0})
        yield pages.PracticeLottery
        yield pages.Announce_Choice
        yield (pages.Staircase1, {'staircase1_GPSrisk': random.choice([True, False])})
        yield pages.Announce_Choice
        yield (pages.Staircase2, {'staircase2_GPSrisk': random.choice([True, False])})
        yield pages.Announce_Choice
        yield (pages.Staircase3, {'staircase3_GPSrisk': random.choice([True, False])})
        yield pages.Announce_Choice
        yield (pages.Staircase4, {'staircase4_GPSrisk': random.choice([True, False])})
        yield pages.Announce_Choice
        yield (pages.Staircase5, {'staircase5_GPSrisk': random.choice([True, False])})
        yield pages.Riskresult
