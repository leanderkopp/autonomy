from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)


authors = 'Jana Freundt, Leander Kopp, University of Fribourg'

doc = """
Autonomy PET based on the staircase price list in Falk et al's GPS
Part 1: choices between lotteries to reveal lotteries between which a participant is indifferent
Part 2: WTP to decide or to buy decision right
Part 3: questionnaire with socio-demogr. and aut survey questions
"""


class Constants(BaseConstants):
    name_in_url = 'Teil2_LM_en'
    players_per_group = None
    num_rounds = 1

    # set the language of the experiment **** Note: for English type 'english' for german change to 'german', doing it with capital letters WON'T work
    language = 'english'
    # language = 'german'



    players=[1,2,3]
    player2_fee = 6
    show_up_fee = 4 #4CHF in Aare-Lab
    survey_fee = 6
    pass




class Subsession(BaseSubsession):
# 3 subsessions: part1, part2 and questionnaire
    pass



class Group(BaseGroup):
    number_of_players = models.IntegerField(initial=0) #Variable to get number of players
    test = models.StringField(initial='not changed')

class Player(BasePlayer):
    #Variables from GPS_Risk --> needs import logic when apps will be united
    riskc = models.FloatField(initial=1)
    lotteryB = models.FloatField(initial=16.0)
    lotteryB_high = models.FloatField(initial=18.0)
    lotteryB_low = models.FloatField(initial=9.0)

    lotteryA_high = models.FloatField(initial=8)
    lotteryA_low = models.FloatField(initial=3)
    lotteryA = models.FloatField(initial=1.6) #get this value from part I!

    autonomous_decision = models.BooleanField(initial=False)

    selected_lottery = models.StringField()
    lottery_outcome_pre = models.FloatField()
    lottery_outcome = models.FloatField()
    #variables for random selection of one decision of the staircase
    selected_decision_price = models.FloatField() #stores the decision (make decision an pay price or let someone else decide)
    inverse_selected_decision_price = models.FloatField() #for display purposes
    selected_decision = models.BooleanField() #stores price at the random selected stage of the staircase

    #variables for staircase decisions
    staircase1=models.BooleanField()
    staircase2=models.BooleanField()
    staircase3=models.BooleanField()
    staircase4=models.BooleanField()
    staircase5=models.BooleanField()
    staircase6=models.BooleanField()

    announceChoiceCounter = models.IntegerField(initial=1) #only for display purposes

    #key variable for WTP for autonomy
    WTPautonomy = models.FloatField(initial=0)
    Inverse_WTPautonomy = models.FloatField(initial=0) #only for display pursposes

    #variables for payout information from part I
    payout_part1 = models.FloatField()
    situation_part1 = models.IntegerField()
    lottery_part1 = models.StringField()

    #control variables for player with decision maker role
    Decisions = models.BooleanField(initial=False)

    decide_for_someone_else = models.BooleanField()
    decision_for_someone_else = models.BooleanField()

    decision_for_player1 = models.BooleanField(blank=True)
    decision_for_player2 = models.BooleanField(blank=True)
    decision_for_player3 = models.BooleanField()
    decision_for_player4 = models.BooleanField()
    decision_for_player5 = models.BooleanField()
    decision_for_player6 = models.BooleanField()
    decision_for_player7 = models.BooleanField()
    decision_for_player8 = models.BooleanField()
    decision_for_player9 = models.BooleanField()


    #Decision Variables
    decisionForRiskc1 = models.BooleanField(blank=True)
    decisionForRiskc2 = models.BooleanField(blank=True)
    decisionForRiskc3 = models.BooleanField()
    decisionForRiskc4 = models.BooleanField()
    decisionForRiskc5 = models.BooleanField()
    decisionForRiskc6 = models.BooleanField()
    decisionForRiskc7 = models.BooleanField()
    decisionForRiskc8 = models.BooleanField()
    decisionForRiskc9 = models.BooleanField()
    decisionForRiskc10 = models.BooleanField()
    decisionForRiskc11 = models.BooleanField()
    decisionForRiskc12 = models.BooleanField()
    decisionForRiskc13 = models.BooleanField()
    decisionForRiskc14 = models.BooleanField()
    decisionForRiskc15 = models.BooleanField()
    decisionForRiskc16 = models.BooleanField()
    decisionForRiskc17 = models.BooleanField()
    decisionForRiskc18 = models.BooleanField()
    decisionForRiskc19 = models.BooleanField()
    decisionForRiskc20 = models.BooleanField()
    decisionForRiskc21 = models.BooleanField()
    decisionForRiskc22 = models.BooleanField()
    decisionForRiskc23 = models.BooleanField()
    decisionForRiskc24 = models.BooleanField()
    decisionForRiskc25 = models.BooleanField()
    decisionForRiskc26 = models.BooleanField()
    decisionForRiskc27 = models.BooleanField()
    decisionForRiskc28 = models.BooleanField()
    decisionForRiskc29 = models.BooleanField()
    decisionForRiskc30 = models.BooleanField()
    decisionForRiskc31 = models.BooleanField()
    decisionForRiskc32 = models.BooleanField()

    decisionForPlayer1 = models.BooleanField(blank=True)
    decisionForPlayer2 = models.BooleanField(blank=True)
    decisionForPlayer3 = models.BooleanField(blank=True)
    decisionForPlayer4 = models.BooleanField(blank=True)
    decisionForPlayer5 = models.BooleanField(blank=True)
    decisionForPlayer6 = models.BooleanField(blank=True)
    decisionForPlayer7 = models.BooleanField(blank=True)
    decisionForPlayer8 = models.BooleanField(blank=True)
    decisionForPlayer9 = models.BooleanField(blank=True)
    decisionForPlayer10 = models.BooleanField(blank=True)
    decisionForPlayer11 = models.BooleanField(blank=True)
    decisionForPlayer12 = models.BooleanField(blank=True)
    decisionForPlayer13 = models.BooleanField(blank=True)
    decisionForPlayer14 = models.BooleanField(blank=True)
    decisionForPlayer15 = models.BooleanField(blank=True)
    decisionForPlayer16 = models.BooleanField(blank=True)
    decisionForPlayer17= models.BooleanField(blank=True)
    decisionForPlayer18 = models.BooleanField(blank=True)
    decisionForPlayer19 = models.BooleanField(blank=True)
    decisionForPlayer20 = models.BooleanField(blank=True)

    decisionForMe = models.BooleanField() #for payout screen
    #timetracking variables
    GPSfocus = models.FloatField(blank=True)
    GPSunfocus = models.FloatField(blank=True)
    GPSfocusevent = models.FloatField(blank=True)
    GPSvisibevent = models.FloatField(blank=True)


    #control question variables for player P

    ControlQuestionP1 = models.IntegerField(min=1)
    ControlQuestionP2 = models.IntegerField(min=1)
    ControlQuestionP3 = models.StringField()

    #control question variables for player D

    ControlQuestionD1 = models.IntegerField()
    ControlQuestionD2 = models.IntegerField()
    ControlQuestionD3 = models.IntegerField()
    ControlQuestionD4 = models.IntegerField()
    ControlQuestionD5 = models.IntegerField()
    ControlQuestionD6 = models.IntegerField()

    #Control question counter for player 1 and 2

    counterWrong = models.IntegerField(initial=0)

    #Time-Variables
    time_part2_P1instructions = models.FloatField()
    time_part2_P1instructions_unfocus = models.FloatField()
    time_part2_P1staircases = models.FloatField()
    time_part2_P1staircases_unfocus = models.FloatField()

    time_part2_P2instructions = models.FloatField()
    time_part2_P2instructions_unfocus = models.FloatField()
    time_part2_P2delegatedchoices = models.FloatField()
    time_part2_P2delegatedchoices_unfocus = models.FloatField()
