from otree.api import Currency as c, currency_range
from . import models
from ._builtin import Page, WaitPage
from .models import Constants
import random
#from otree_tools.utils import get_focused_time, get_unfocused_time, get_time_per_page, num_focusoff_events


# ****ID 1 IS THE PASSIVE PLAYER****


class Intro_Title(Page):
    def before_next_page(self):
        self.group.number_of_players=len(self.group.get_players())



class Intro_Types_1(Page):
    def before_next_page(self):
        #Read payout information from part 1
        try:
            self.player.payout_part1= self.participant.vars['payout_part1']
        except:
            #print('part 1 was not completed')
            self.player.payout_part1=0
        try:
            if self.participant.vars['lottery_part1']==True:
                self.player.lottery_part1='Lotterie B'
            elif self.participant.vars['lottery_part1']==False:
                self.player.lottery_part1 = 'Lotterie A'
        except:
            #print('part 1 was not completed')
            self.player.lottery_part1="*** NOT PLAYED ***"
        try:
            self.player.situation_part1= self.participant.vars['situation_part1']
        except:
            #print('part 1 was not completed')
            self.player.situation_part1=0

class P1_Intro_General_2(Page):
    def is_displayed(self):
        if self.player.id_in_group == 1:
            return False
        else:
            return True

    def before_next_page(self):
        #Read the needed information from Part 1, namely Riskcategory (riskc) and define the corresponding lotteries
        try:
            self.player.riskc=self.participant.vars['risk_category']
            #print(self.player.lotteryA)
        except:
            #print('an error occured couldnt get risk cat')
            self.player.riskc = random.randint(15,15) # this code will be executed if app is launched without GPSrisk before
        if self.player.riskc == 1:
            self.player.lotteryB_low = 6.00
            self.player.lotteryB_high = 6.00
        elif self.player.riskc == 32:
            self.player.lotteryB_low = 3
            self.player.lotteryB_high = 12
        else:
            self.player.lotteryB_low = 6.05 - (self.player.riskc-1)*0.1
            self.player.lotteryB_high = 5.9 + (self.player.riskc-1)*0.2
        #self.player.lotteryA = ((self.player.riskc * 2 - 1) / 2) / 10


class P1_Description_Lotteries(Page):
    def is_displayed(self):
        if self.player.id_in_group == 1:
            return False
        else:
            return True

class P1_Description_Choice(Page):
    def is_displayed(self):
        if self.player.id_in_group == 1:
            return False
        else:
            return True

class P1_ControlQuestions(Page):
    form_model = 'player'
    form_fields = ['ControlQuestionD1','ControlQuestionD2','ControlQuestionD3','ControlQuestionD4','ControlQuestionD5','ControlQuestionD6','counterWrong']
    def is_displayed(self):
        return self.player.id_in_group != 1

class P1_Announce_Choice(Page):
    def is_displayed(self):
        if self.player.id_in_group == 1:
            return False
        else:
            return True

    def before_next_page(self):
        self.player.announceChoiceCounter+=1



class P1_Staircase1(Page):
    form_model = 'player'
    form_fields = ['staircase1']
    # STAIRCASE-ALGORITHM:
    # see Staircase and its asked prices
    # A list 'decisions' is defined (since it isn't possible to create lists in the Player-Class in models.py, we need to use self.participant.vars)
    # 'decisions' contains all decisions for every price at every stage (i.e. every element of the list contains a price p and a boolean, indicating if the player is willing to pay p (True if player is willing to pay p, False if not)
    # In templates, the player sees the current asked price for his decision right. If he doesn't accept, the price will be lower in the next step of the staircase and higher if he accepts.
    # Example for stage one: If the player doesn't accept WTPAutonomy (intial value = 0, defined in Constant-Class in models.py), WTPAutonomy is lowered by 0.80 for the next stage,
    # If the player accepts, WTPAutonomy is raised by 0.80 for the next stage.
    # The decision and the asked price for Stage1 are saved into the list 'decisions'
    # At the end, we only need to look at the variable player.WTPAutonomy, which shows the maximum price the player is willing to pay
    def before_next_page(self):
        #print("risk cat", self.player.riskc)


        self.participant.vars['decisions'] = list() # define list of subjects decision
        if self.player.staircase1==True: #if player accepts to pay price p
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 1, self.player.id_in_group]) #save decision for price p in 'decisions'
            self.player.WTPautonomy+=0.80 #since player accepts to pay price p, p will be higher in the next stage.
        elif self.player.staircase1==False: #if player doesn't accept to pay price p
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 1, self.player.id_in_group]) #save decision for price p in 'decisions'
            self.player.WTPautonomy+=-0.80 #since player doesn't accepts to pay price p, p will be lower in the next stage.
        #print(self.player.WTPautonomy) #FOR TESTING PURPOSES
        #print(self.participant.vars['decisions']) #FOR TESTING PURPOSES
        self.group.test="changed"

        self.player.Inverse_WTPautonomy=-self.player.WTPautonomy
    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True

class P1_Staircase2(Page):
    form_model = 'player'
    form_fields = ['staircase2']
    def before_next_page(self):
        if self.player.staircase2==True:
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 2, self.player.id_in_group])
            self.player.WTPautonomy+=0.40
        elif self.player.staircase2 == False:
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 2, self.player.id_in_group])
            self.player.WTPautonomy += -0.40

        self.player.Inverse_WTPautonomy = -self.player.WTPautonomy
    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True

class P1_Staircase3(Page):
    form_model = 'player'
    form_fields = ['staircase3']
    def before_next_page(self):
        if self.player.staircase3==True:
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 3, self.player.id_in_group])
            self.player.WTPautonomy+=0.20
        elif self.player.staircase3 == False:
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 3, self.player.id_in_group])
            self.player.WTPautonomy += -0.20

        self.player.Inverse_WTPautonomy = -self.player.WTPautonomy
    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True

class P1_Staircase4(Page):
    form_model = 'player'
    form_fields = ['staircase4']
    def before_next_page(self):
        if self.player.staircase4==True:
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 4, self.player.id_in_group])
            self.player.WTPautonomy+=0.10
        elif self.player.staircase4 == False:
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 4, self.player.id_in_group])
            self.player.WTPautonomy += -0.10

        self.player.Inverse_WTPautonomy = -self.player.WTPautonomy
    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True

class P1_Staircase5(Page):
    form_model = 'player'
    form_fields = ['staircase5']
    def before_next_page(self):

        if self.player.staircase5==True:
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 5, self.player.id_in_group])
            self.player.WTPautonomy+=0.05
        elif self.player.staircase5 == False:
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 5, self.player.id_in_group])
            self.player.WTPautonomy += -0.05
        self.player.Inverse_WTPautonomy = -self.player.WTPautonomy

    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True

class P1_Staircase6(Page):
    form_model = 'player'
    form_fields = ['staircase6']
    def before_next_page(self):

        if self.player.staircase6==True:
            self.participant.vars['decisions'].append([True, self.player.WTPautonomy, 6, self.player.id_in_group])
            self.player.WTPautonomy+=0.05
        elif self.player.staircase6 == False:
            self.participant.vars['decisions'].append([False, self.player.WTPautonomy, 6, self.player.id_in_group])
            self.player.WTPautonomy += -0.05
        #print(self.participant.vars['decisions']) #FOR TESTING PURPOSES

        #Random selection of one decision made in the different stages of the staircase
        self.participant.vars['selected_decision']=random.choice(self.participant.vars['decisions'])

        self.player.selected_decision=self.participant.vars['selected_decision'][0] #write random selection into player variable: here if price p is accepted or not
        self.player.selected_decision_price = self.participant.vars['selected_decision'][1] #write random selection into player variable: here only the price

        self.player.inverse_selected_decision_price = -self.player.selected_decision_price

        #print(self.participant.vars['selected_decision']) #FOR TESTING PURPOSES

        #if self.participant.vars['selected_decision'][0]==True: #FOR TESTING PURPOSES
            #print("selber wählen") #FOR TESTING PURPOSES
        #elif self.participant.vars['selected_decision'][0]==False: #FOR TESTING PURPOSES
            #print("jemand anders wählt") #FOR TESTING PURPOSES

        self.player.Inverse_WTPautonomy = -self.player.WTPautonomy

    def is_displayed(self):
        if self.player.id_in_group==1:
            return False
        else:
            return True


class P2_DescriptionChoice(Page): #page for decision maker instructions
    def is_displayed(self):
        self.player.lottery_outcome = Constants.player2_fee
        return self.player.id_in_group == 1  #skip page if subject isn't selected as decision maker

class P2_DescriptionLotteries(Page): #page for decision maker instructions
    def before_next_page(self):
        # set up lotteries for display in DecideForOthers.html
        self.player.lotteryB_high = 12
        self.player.lotteryB_low = 12
        #set up lists for decisions and loop in DecideforOthers.html
        self.participant.vars['StrategyMethod_decisions'] = list()
        self.participant.vars['Counter'] = list()
        #set up lotteries for display in DecideforOthers.html
        for i in range(0,32):
            self.participant.vars['Counter'].append([i,self.player.lotteryB_high+i*0.40,self.player.lotteryB_low-i*0.20])


    def is_displayed(self):
        return self.player.id_in_group == 1  #skip page if subject isn't selected as decision maker

class WaitForPlayers1(WaitPage):
    if Constants.language=='english':
        title_text = "Please Wait"
        body_text = "Waiting for the other participants."
    elif Constants.language=='german':
        title_text = "Bitte warten Sie"
        body_text = "Warten auf die anderen Teilnehmer."

    def is_displayed(self):
        return not self.player.autonomous_decision

    def after_all_players_arrive(self):
        for i in self.group.get_players():
            #self.group.number_of_players=1+self.group.number_of_players
            self.group.number_of_players=self.group.number_of_players
        self.group.get_player_by_id(1).participant.vars['playerID_delegations']=list()
        for i in range(self.group.number_of_players-1):
            if self.group.get_player_by_id(i+2).participant.vars['selected_decision'][0]==False:
                self.group.get_player_by_id(1).Decisions=True
                self.group.get_player_by_id(1).participant.vars['playerID_delegations'].append([self.group.get_player_by_id(i+2).participant.vars['selected_decision'][3], self.group.get_player_by_id(i+2).lotteryB_high, self.group.get_player_by_id(i+2).lotteryB_low])

class P2_ControlQuestions(Page):
    form_model = 'player'
    form_fields = ['ControlQuestionP1','ControlQuestionP2','ControlQuestionP3', 'counterWrong']
    def is_displayed(self):
        return self.player.id_in_group == 1
    #def before_next_page(self):
        #print("Fehlversucher",self.player.counterWrong)
class P2_Delegated_Choice_Intro(Page):
    def is_displayed(self):
        return self.player.id_in_group == 1

class P2_Delegated_Choice(Page): #page for decision maker instructions works ATM only for 4 players
    form_model = 'player'
    form_fields = ['decisionForPlayer1','decisionForPlayer2','decisionForPlayer3','decisionForPlayer4','decisionForPlayer5',
                   'decisionForPlayer6','decisionForPlayer7','decisionForPlayer8','decisionForPlayer9','decisionForPlayer10',
                   'decisionForPlayer11','decisionForPlayer12','decisionForPlayer13','decisionForPlayer14','decisionForPlayer15',
                   'decisionForPlayer16','decisionForPlayer17','decisionForPlayer18','decisionForPlayer19','decisionForPlayer20'
                   ]
    def before_next_page(self):
        #setup list
        self.participant.vars['LiveMatching_decisions'] = [self.player.decisionForPlayer1,self.player.decisionForPlayer2,self.player.decisionForPlayer3,self.player.decisionForPlayer4,
                                                           self.player.decisionForPlayer5,self.player.decisionForPlayer6,self.player.decisionForPlayer7,self.player.decisionForPlayer8,
                                                           self.player.decisionForPlayer9,self.player.decisionForPlayer10,self.player.decisionForPlayer11,self.player.decisionForPlayer12,
                                                           self.player.decisionForPlayer13,self.player.decisionForPlayer14,self.player.decisionForPlayer15,self.player.decisionForPlayer16,
                                                           self.player.decisionForPlayer17,self.player.decisionForPlayer18,self.player.decisionForPlayer19,self.player.decisionForPlayer20]


    def is_displayed(self):
        #get numbers of active players! Caution retest this before launch
        #self.group.number_of_players=0
        #for i in self.group.get_players():
        #    self.group.number_of_players=1+self.group.number_of_players
        display=False
        if self.player.id_in_group == 1: #skip page if subject isn't selected as decision maker
            display=True
            if self.player.Decisions == False:
                display=False

        return display

class WaitForPlayer2(WaitPage): #waiting page for player where a player waits for the choice of the decision maker
    if Constants.language=='english':
        title_text = "Please Wait"
        body_text = "Waiting for the other participant."
    elif Constants.language=='german':
        title_text = "Bitte warten Sie"
        body_text = "Warten auf die anderen Teilnehmer."


    def is_displayed(self):
        return not self.player.autonomous_decision

    def after_all_players_arrive(self):

        #set selected lotteries for players who gave up their decision right
        a=-1
        for i in range(self.group.number_of_players-1):

            a=a+1
            if self.group.get_player_by_id(i+2).selected_decision==False:
                if self.group.get_player_by_id(1).participant.vars['LiveMatching_decisions'][i+1]==True: #LotteryB was selected by decisionmaker
                    self.group.get_player_by_id(i+2).selected_lottery = "LotteryB"
                else:
                    self.group.get_player_by_id(i+2).selected_lottery = "LotteryA"

                if self.group.get_player_by_id(i+2).selected_lottery == "LotteryA":  # determine outcome, if lottery A was selected by player
                    self.group.get_player_by_id(i+2).lottery_outcome = random.choice(
                        [self.group.get_player_by_id(i+2).lotteryA_high, self.group.get_player_by_id(i+2).lotteryA_high, self.group.get_player_by_id(i+2).lotteryA_high,
                         self.group.get_player_by_id(i+2).lotteryA_low])  # determine outcome
                elif self.group.get_player_by_id(i+2).selected_lottery == "LotteryB":  # determine outcome, if lottery B was selected by player
                    self.group.get_player_by_id(i+2).lottery_outcome = random.choice([self.group.get_player_by_id(i+2).lotteryB_high,self.group.get_player_by_id(i+2).lotteryB_low]) # determine outcome of lottery B - price for decision right#### CAUTION: If changes in the lottery payout structure occur, manually change this here, look for a better solution!

            # set payoff for part 2 for data purposes
            self.group.get_player_by_id(i+2).participant.vars['payout_part2'] = self.group.get_player_by_id(i+2).lottery_outcome
            # set total payoff for results page and part III
            self.group.get_player_by_id(i+2).participant.vars['total_payoff'] = self.group.get_player_by_id(i+2).payout_part1 + self.group.get_player_by_id(i+2).lottery_outcome + Constants.show_up_fee
        #set payoff for part 2 separately for passive player
        self.group.get_player_by_id(1).participant.vars['payout_part2'] = self.group.get_player_by_id(1).lottery_outcome
        #set total payoff separately for passive player
        self.group.get_player_by_id(1).participant.vars['total_payoff'] = self.group.get_player_by_id(1).payout_part1 + self.group.get_player_by_id(1).lottery_outcome + Constants.show_up_fee

class P1_Decision_Self(Page): #page will only be displayed if the selected decision from the staircase states, that the player wants to choose the lotteries and pays price p
    form_model = 'player'
    form_fields = ['selected_lottery']
    def before_next_page(self):
        self.player.autonomous_decision=True
        if self.player.selected_lottery=="LotteryA": #determine outcome, if lottery A was selected by player
            self.player.lottery_outcome_pre = random.choice([self.player.lotteryA_high,self.player.lotteryA_high,self.player.lotteryA_high,self.player.lotteryA_low])
            self.player.lottery_outcome= self.player.lottery_outcome_pre - self.player.selected_decision_price #determine outcome - price for decision right
        elif self.player.selected_lottery=="LotteryB": #determine outcome, if lottery B was selected by player
            self.player.lottery_outcome_pre = random.choice([self.player.lotteryB_high,self.player.lotteryB_low])
            self.player.lottery_outcome = self.player.lottery_outcome_pre - self.player.selected_decision_price #determine outcome of lottery B - price for decision right#### CAUTION: If changes in the lottery payout structure occur, manually change this here, look for a better solution!

        #print("selected lottery",self.player.selected_lottery) #FOR TESTING PURPOSES
        #print("selected price",self.player.selected_decision_price)
        #print("lottery_outcome",self.player.lottery_outcome)    #FOR TESTING PURPOSES
        #set total payoff
        self.participant.vars['total_payoff'] = self.player.payout_part1 + self.player.lottery_outcome + Constants.show_up_fee
        self.participant.vars['payout_part2'] = self.player.lottery_outcome

    def is_displayed(self): #this page is only displayed for a player who went through the staircase and is only displayed, if the selected decision was, that the player wants to choose and pays p
        if self.player.id_in_group == 1: #this page won't be shown to a player with a decision maker role
            return False
        else:
            return self.participant.vars['selected_decision'][0] == True #show to player only if only displayed, if the selected decision was, that the player wants to choose and pays p

class P1_Wait_DelegatedChoice(Page): #page will only be displayed if the selected decision from the staircase states, that the player wants to choose the lotteries and pays price p
    def is_displayed(self): #this page is only displayed for a player who went through the staircase and is only displayed, if the selected decision was, that the player wants to choose and pays p
        if self.player.id_in_group == 1: #this page won't be shown to a player with a decision maker role
            return False
        else:
            return self.participant.vars['selected_decision'][0] == False #show to player only if only displayed, if the selected decision was, that the player wants to give up his decision right

class ResultsWaitPage(WaitPage):
    def after_all_players_arrive(self):
        pass

class Both_PayoffScreen(Page):
    def before_next_page(self):
        pages_P1instructions = ['Intro_Title', 'Intro_Types_1', 'P1_Intro_General_2','P1_Description_Lotteries','P1_Description_Choice']
        pages_P1staircases =['P1_Staircase1', 'P1_Staircase2', 'P1_Staircase3', 'P1_Staircase4', 'P1_Staircase5', 'P1_Staircase6']

        pages_P2instructions = ['P2_DescriptionChoice','P2_DescriptionLotteries',]
        pages_P2decisions = ['WaitForPlayers1','P2_Delegated_Choice_Intro','P2_Delegated_Choice']

        self.player.time_part2_P1instructions = sum([get_time_per_page(self.player, i) for i in pages_P1instructions])
        self.player.time_part2_P1instructions_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_P1instructions])
        self.player.time_part2_P1staircases= sum([get_time_per_page(self.player, i) for i in pages_P1staircases])
        self.player.time_part2_P1staircases_unfocus= sum([get_unfocused_time(self.player, i) for i in pages_P1staircases])

        self.player.time_part2_P2instructions = sum([get_time_per_page(self.player, i) for i in pages_P2instructions])
        self.player.time_part2_P2instructions_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_P2instructions])
        self.player.time_part2_P2delegatedchoices = sum([get_time_per_page(self.player, i) for i in pages_P2decisions])
        self.player.time_part2_P2delegatedchoices = sum([get_time_per_page(self.player, i) for i in pages_P2decisions])

class DONE(Page):
    def before_next_page(self):
        pages = ['Block0', 'Block1', 'Block2']
        try:
            self.player.GPStime = sum([get_time_per_page(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.GPStime = 0
            #print(err)
        try:
            self.player.GPSfocus = sum([get_focused_time(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.GPSfocus = 0
            #print(err)
        try:
            self.player.GPSunfocus = sum([get_unfocused_time(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.GPSunfocus = 0
            #print(err)
        self.player.GPSfocusevent = sum([num_focusoff_events(self.player, i) for i in pages])


page_sequence = [
  Intro_Title, Intro_Types_1, P1_Intro_General_2,P1_Description_Lotteries,P1_Description_Choice,
    P1_ControlQuestions,
    P1_Announce_Choice,P1_Staircase1,
    P1_Announce_Choice,P1_Staircase2,
    P1_Announce_Choice,P1_Staircase3,
    P1_Announce_Choice,P1_Staircase4,
    P1_Announce_Choice,P1_Staircase5,
    P1_Announce_Choice,P1_Staircase6,
    P1_Wait_DelegatedChoice,
    P2_DescriptionChoice,
    P2_DescriptionLotteries,
    P2_ControlQuestions,
    P1_Decision_Self,
    WaitForPlayers1,
    P2_Delegated_Choice_Intro,
    P2_Delegated_Choice,
    #P1_Wait_DelegatedChoice,
    WaitForPlayer2,
    Both_PayoffScreen]
