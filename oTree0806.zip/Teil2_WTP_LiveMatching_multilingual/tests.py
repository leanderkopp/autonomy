from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
from .models import Constants
import random

class PlayerBot(Bot):

    def play_round(self):
        #yield (pages.MyPage)
        #yield (pages.Results)
        #yield (pages.Block0, {'q1':0})
        #yield (pages.Block1, {'q1': 0})
        #yield (pages.Block2, {'q1': 0})

        yield pages.Intro_Types_1

        if self.player.id_in_group >= 2:
            yield pages.P1_Intro_General_2
            yield pages.P1_Description_Lotteries
            yield pages.P1_Description_Choice
            # yield pages.P1_ControlQuestions
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase1, {'staircase1': random.choice([False, True])})
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase2, {'staircase2': random.choice([False, True])})
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase3, {'staircase3': random.choice([False, True])})
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase4, {'staircase4': random.choice([True, False])})
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase5, {'staircase5': random.choice([True, False])})
            yield pages.P1_Announce_Choice
            yield (pages.P1_Staircase6, {'staircase6': random.choice([True, False])})
            if self.participant.vars['selected_decision'][0] == False:
                yield pages.P1_Wait_DelegatedChoice
            if self.participant.vars['selected_decision'][0] == True:
                yield (pages.P1_Decision_Self, {'selected_lottery': random.choice(["LotteryA", "LotteryB"])})
            yield pages.Both_PayoffScreen