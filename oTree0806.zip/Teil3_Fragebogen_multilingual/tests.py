from otree.api import Currency as c, currency_range
from . import pages
from ._builtin import Bot
import random
from random import randrange
from .models import Constants


class PlayerBot(Bot):

    def play_round(self):
        yield  (pages.QBlock1, {'Contr_RiskGen': randrange(100)/100, 'Contr_Trust': randrange(100)/100, 'Contr_Give': randrange(1000)})
        yield (pages.QBlock2, {'Aut_Work_Prefs1': randrange(100)/100,'Aut_Work_Prefs2': randrange(100)/100,'Aut_Work_Prefs3': randrange(100)/100})
        yield (pages.QBlock3, {'Aut_SE1': randrange(100)/100,'Aut_SE2': randrange(100)/100,'Aut_SE3': randrange(100)/100,'Aut_SE4': randrange(100)/100,'Aut_SE5': randrange(100)/100})
        yield (pages.QBlock3_2, {'Aut_SE6': randrange(100)/100,'Aut_SE7': randrange(100)/100, 'Aut_AttnCheck1': 1, 'Aut_SE8': randrange(100)/100,'Aut_SE9': randrange(100)/100,'Aut_SE10': randrange(100)/100})
        yield (pages.QBlock4, {'Aut_Vote': randrange(3)+1, 'Aut_Indep_Work': randrange(100)/100, 'Aut_AttnCheck2': 1, 'Aut_Gov': randrange(100)/100})
        yield (pages.QBlock5, {'Aut_Pol_Action1': randrange(2)+1, 'Aut_Pol_Action2': randrange(2)+1, 'Aut_Pol_Action3': randrange(2)+1, 'Aut_Pol_Action4': randrange(2)+1, 'Aut_Pol_Action5': randrange(2)+1})
        yield (pages.QBlock6, {'Dem_Field_of_study':"Economics", 'Dem_Highest_degree': randrange(5)+1, 'Dem_Party': randrange(7)+1, 'Dem_Pol_View': randrange(2)+1, 'Dem_Gender': randrange(3), 'Dem_Age': randrange(99)+1})
        yield pages.Feedback1
        yield pages.Feedback2
        yield pages.Feedback3
        yield pages.PayoutInfo
        yield pages.DONE
        yield pages.Results