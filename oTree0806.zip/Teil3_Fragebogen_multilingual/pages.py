from otree.api import Currency as c, currency_range
from ._builtin import Page, WaitPage
from .models import Constants
from slider_task.pages import SliderTaskPage
#from otree_tools.utils import get_focused_time, get_unfocused_time, get_time_per_page, num_focusoff_events, get_seconds_per_page

class Intro_Title(Page):
    pass

class QBlock1(Page): #here also all final payoffs are defined
    form_model = 'player'
    form_fields = ['Contr_RiskGen', 'Contr_Trust', 'Contr_Give']
    def before_next_page(self):
        try:
            self.player.total_payoff = self.participant.vars['total_payoff'] + Constants.survey_fee
            self.player.finalpayoff_part1 = self.participant.vars['payout_part1']
            self.player.finalpayoff_part2 = self.participant.vars['payout_part2']
            self.player.finalpayoff_part3 = Constants.show_up_fee + Constants.survey_fee
            self.player.total_payoff = self.player.finalpayoff_part1 + self.player.finalpayoff_part2 + self.player.finalpayoff_part3
            self.player.finalpayoff = self.player.finalpayoff_part1 + self.player.finalpayoff_part2 + self.player.finalpayoff_part3
        except:
            self.player.total_payoff = Constants.show_up_fee + Constants.survey_fee

        self.player.payoff= self.player.total_payoff - Constants.show_up_fee - Constants.survey_fee # set payoff for oTree-Backend, so that we can see it solely and make receipts
        self.player.payoff_pre = self.player.total_payoff - Constants.survey_fee
        self.session.config['participation_fee']= Constants.show_up_fee + Constants.survey_fee # set show-up fee
        self.participant.label=str(self.player.id_in_group)

class QBlock2(Page):
    form_model = 'player'
    form_fields = ['Aut_Work_Prefs1','Aut_Work_Prefs2','Aut_Work_Prefs3']

class QBlock3(Page):
    form_model = 'player'
    form_fields = ['Aut_SE1','Aut_SE2','Aut_SE3','Aut_SE4','Aut_SE5']

class QBlock3_2(Page):
    form_model = 'player'
    form_fields = ['Aut_SE6','Aut_SE7', 'Aut_AttnCheck1', 'AttnCheck1_fail', 'Aut_SE8','Aut_SE9','Aut_SE10']

class QBlock4(Page):
    form_model = 'player'
    form_fields = ['Aut_Vote', 'Aut_Elect', 'Aut_AttnCheck2','AttnCheck2_fail', 'Aut_Gov']

class QBlock5(Page):
    form_model = 'player'
    form_fields = ['Aut_Pol_Action1', 'Aut_Pol_Action2', 'Aut_Pol_Action3', 'Aut_Pol_Action4', 'Aut_Pol_Action5',]

class QBlock6(Page):
    form_model = 'player'
    form_fields = ['Dem_Field_of_study', 'Dem_Highest_degree', 'Dem_Party', 'Dem_Pol_View', 'Dem_Gender', 'Dem_Nationality', 'Dem_Age']


class QBlock7(Page):
    form_model = 'player'
    form_fields = ['Feedback1_11','Feedback1_12','Feedback1_21','Feedback1_22','Feedback1_3']

class Feedback1(Page):
    form_model = 'player'
    form_fields = ['Feedback1_11','Feedback1_12','Feedback1_21','Feedback1_22','Feedback1_3']

class Feedback2(Page):
    form_model = 'player'
    form_fields = ['Feedback1_4','Feedback1_5', 'Feedback1_6','Feedback2_11', 'Feedback2_12']

class Feedback3(Page):
    form_model = 'player'
    form_fields = ['Feedback2_21', 'Feedback2_22', 'Feedback2_3', 'Feedback2_4','Feedback2_5', 'Feedback2_6']

    #def before_next_page(self):
        #pages_survey = ['QBlock1', 'QBlock2', 'QBlock3', 'QBlock4', 'QBlock5', 'QBlock6', 'QBlock7']
        #pages_feedback = ['Feedback1','Feedback2','Feedback3']
        #self.player.time_part3_survey = sum([get_time_per_page(self.player, i) for i in pages_survey])
        #self.player.time_part3_survey_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_survey]) - self.player.time_part3_survey

        #self.player.time_part3_feedback = sum([get_time_per_page(self.player, i) for i in pages_feedback])
        #self.player.time_part3_feedback_unfocus = sum([get_unfocused_time(self.player, i) for i in pages_feedback]) - self.player.time_part3_feedback


class PayoutInfo(Page):
    pass




class ResultsWaitPage(WaitPage):
    title_text = "Please wait"
    body_text =   "Please remain seated and wait until everyone finished the questionnaire."
    def after_all_players_arrive(self):
        pass

class DONE(Page): #Leander: needs work!
    def before_next_page(self):
        pages = ['QBlock1']#, 'QBlock2', 'QBlock3', 'QBlock4', 'QBlock5', 'QBlock6', 'QBlock7']
        print(get_seconds_per_page(self.player, 'QBlock1'))
        print(get_time_per_page(self.player, 'QBlock1'))
        try:
            self.player.Qtime = sum([get_time_per_page(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.Qtime = 0
            print(err)
            print('hi')
        try:
            self.player.Qfocus = sum([get_focused_time(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.Qfocus = 0
            print(err)
        try:
            self.player.Qunfocus = sum([get_unfocused_time(self.player, i) for i in pages])
        except (AttributeError, TypeError) as err:
            self.player.Qunfocus = 0
            print(err)
        self.player.Qfocusevent = sum([num_focusoff_events(self.player, i) for i in pages])

class Results(Page):
    pass


page_sequence = [
    Intro_Title,
    QBlock1,QBlock2, QBlock3,
    QBlock3_2,
    QBlock4,
    QBlock5,
    QBlock6,
    Feedback1,
    Feedback2,
    Feedback3,
    PayoutInfo,
]
