from otree.api import (
    models, widgets, BaseConstants, BaseSubsession, BaseGroup, BasePlayer,
    Currency as c, currency_range
)
#from slider_task.models import BaseSlider, SliderPlayer

author = 'Jana Freundt, University of Fribourg'

doc = """
Autonomy PET based on the staircase price list in Falk et al's GPS
Part 1: choices between lotteries to reveal lotteries between which a participant is indifferent
Part 2: WTP to decide or to buy decision right
Part 3: questionnaire with socio-demogr. and aut survey questions
"""


class Constants(BaseConstants):
    name_in_url = 'Teil3_multilingual'
    players_per_group = None
    num_rounds = 1
    # set the language of the experiment **** Note: for English type 'english' for german change to 'german', doing it with capital letters WON'T work
    language = 'english'
    # language = 'german'
    show_up_fee = 4  # 4CHF in Aare-Lab
    survey_fee = 6

class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    # QUESTIONNAIRE VARIABLE DEFINITION
    # CONTROLS
    #####  QBlock1
    Contr_RiskGen = models.FloatField(min=0,max=1,
                                      verbose_name='On a scale from 0 to 10, where 0 means you are "completely unwilling to take risks" and a 10 means you are "very willing to take risks", how willing are you to take risks in general?',
                                      widget=widgets.Slider(attrs={'step': '0.01'}))
    # HOW TO ADD F****** LABELS TO SLIDERS????????? #Leander: this can be done with HTML/CSS see QBLock1.html
    # HOW TO DEFINE THE VALUES THE SLIDER SSHOULD TAKE ON, I.E. 0 TO 1 INSTEAD OF 0 TO 100??? NOW THIS AND NEXT QUESTION GIVE ERROR MESSAGES #Leander: this can be done as well with HTML in QBlock1.html

    # HOW TO MAKE LARGER SPACES BETWEEN QUESTIONS? #Leander: this can be done with a simple HTML-tag (<br>), we could also define the spaces more elegant with CSS

    Contr_Trust = models.FloatField(
        # choices=[
        # [0, 'Not at all'],
        # [1, 'Completely']
        # ],
        min=0,max=1,
        verbose_name='I assume that people only have best intentions.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))

    Contr_Give = models.FloatField(
        #min=0, max=1000,
        #verbose_name='Imagine the following situation: Today you unexpectedly received 1000 USD. How much of this amount would you donate to a good cause out of 1000 USD?',
        label='')

    # CUSTOM ERROR MESSAGE THAT SAYS "THE ANSWER HAS TO BE BETWEEN 0 AND 1000":
    def Contr_Give_error_message(self, value):
        print('value is', value)
        if value > 1000:
            return 'Fehler: Ihre Antwort muss kleiner gleich 1000 sein.'
        elif value < 0:
            return 'Fehler: Ihre Antwort muss mindestens 0 sein.'

    # AUTONOMY MEASURES

    # ISSP work orientation 2015 question: does nit have negative items, should we add some?
    # this survey module has some more very interestign questions we should look at for the online survey, but they don't fit well for students in the lab
    #####  QBlock2
    Aut_Work_Prefs1 = models.FloatField(
        #choices=[[1, 'Very Important'], [0, 'Not important at all']],
        min=0,max=1,
        verbose_name='good opportunities for advancement?',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_Work_Prefs2 = models.FloatField(
        #choices=[[1, 'Very Important'], [0, 'Not important at all']],
        min=0,max=1,
        verbose_name='a job that allows someone to work independently?',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_Work_Prefs3 = models.FloatField(
        #choices=[[1, 'Very Important'], [0, 'Not important at all']],
        verbose_name='a job that allows someone to decide their times or days of work?',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))

    # general self-efficacy scale:
    #Leander: Before, all the fields were sliders. Is it meant to be a binary or a free-floating choice between 0 and 1?,
    # if free-floating: We could use a HTML Solution to label the slider! See QBlock1.html
    # Code before: widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    #####  QBlock3
    Aut_SE1 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I can always manage to solve difficult problems if I try hard enough.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE2 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='If someone opposes me, I can find the ways and means to get what I want.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE3 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I am certain that I can accomplish my goals.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE4 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I am confident that I could deal efficiently with unexpected events.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE5 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='Thanks to my resourcefulness, I can handle unforeseen situations.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE6 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I can solve most problems if I invest the necessary effort.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE7 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I can remain calm when facing difficulties because I can rely on my coping abilities.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_AttnCheck1 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='Please move the slider to very true in order to show that you are paying attention.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))

    Aut_SE8 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='When I am confronted with a problem, I can find several solutions.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE9 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='If I am in trouble, I can think of a good solution.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    Aut_SE10 = models.FloatField(
        #choices=[[0, 'Not at all true'], [1, 'Very true']],
        verbose_name='I can handle whatever comes my way.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))

    #####  QBlock4
    Aut_Vote = models.IntegerField(
        choices=[[4, 'Always'], [3, 'Usually'], [2, 'Sometimes'], [1, 'Never']],
        verbose_name='How often do you vote in national and local elections?',
        widget=widgets.RadioSelect)

    Aut_Elect = models.IntegerField(
        choices=[[4, 'Always'], [3, 'Usually'], [2, 'Sometimes'], [1, 'Never']],
        verbose_name='How often do you vote in national and local elections?',
        widget=widgets.RadioSelect)

    Aut_Indep_Work = models.FloatField(
        #choices=[[0, 'No Independence at all'], [1, 'Complete Independence']],
        min=0, max=1,
        verbose_name='How much independence do you have in performing your tasks at work? (If you do not work currently, characterize the last job you had.)',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    # WVS question >> ADJUST FOR STUDENTS IN LAB

    Aut_AttnCheck2 = models.FloatField(
        #choices=[[0, 'Strongly disagree'], [1, 'Strongly agree']],
        min=0, max=1,
        verbose_name='Please move the slider to Strongly Agree in order to show that you are paying attention.',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    AttnCheck2_fail = models.IntegerField()
    AttnCheck1_fail = models.IntegerField()

    Aut_Gov = models.FloatField(
        #choices=[[0, 'Strongly disagree'], [1, 'Strongly agree']],
        min=0, max=1,
        verbose_name='To what extent do you agree or disagree with the following statement? "People like me don\’t have any say about what the government does." ',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))
    # ISSP 2017 question

    #####  QBlock5
    # WVS question
    Aut_Pol_Action1 = models.IntegerField(
        choices=[[5, 'Have done often'],[4, 'Have done multiple times'],[3, 'Have done'], [2, 'Might do'], [1, 'Would never do']],
        verbose_name='Signing a petition',
        widget=widgets.RadioSelect)
    Aut_Pol_Action2 = models.IntegerField(
        choices=[[5, 'Have done often'],[4, 'Have done multiple times'],[3, 'Have done'], [2, 'Might do'], [1, 'Would never do']],
        verbose_name='Joining in boycotts',
        widget=widgets.RadioSelect)
    Aut_Pol_Action3 = models.IntegerField(
        choices=[[5, 'Have done often'],[4, 'Have done multiple times'],[3, 'Have done'], [2, 'Might do'], [1, 'Would never do']],
        verbose_name='Attending peaceful demonstrations',
        widget=widgets.RadioSelect)
    Aut_Pol_Action4 = models.IntegerField(
        choices=[[5, 'Have done often'],[4, 'Have done multiple times'],[3, 'Have done'], [2, 'Might do'], [1, 'Would never do']],
        verbose_name='Joining strikes',
        widget=widgets.RadioSelect)
    Aut_Pol_Action5 = models.IntegerField(
        choices=[[5, 'Have done often'],[4, 'Have done multiple times'],[3, 'Have done'], [2, 'Might do'], [1, 'Would never do']],
        verbose_name='Any other act of protest',
        widget=widgets.RadioSelect)

    #####  QBlock6
    # SOCIO-ECONOMICS
    if Constants.language=='english':
        Dem_Field_of_study = models.StringField(verbose_name='What is your field of study?')

        Dem_Highest_degree = models.IntegerField(
            choices=[[1, 'Less than high school'], [2, 'High School (A levels, Abitur)'], [3, 'professional degree'],
                     [4, 'University degree (Bachelor)'], [5, 'University (degree (Master)'], [6, 'PhD, Doktor']],
            verbose_name='What is the highest degree you have earned so far?')
        # ,widget=widgets.RadioSelect)
        ## It should be a dropdown menu that displays the labels but saves the numbers #Leander: If we want a dropdown menu, we don't need to call a widget

        Dem_Party = models.IntegerField(
            choices=[[1, 'SVP'], [2, 'SP'], [3, 'FDP'], [4, 'CVP'], [5, 'Grüne'], [6, 'GLP'], [7, 'BDP'],
                     [8, 'Other, I don\'t know']],
            verbose_name='If today was an election day, which party would you vote for?')  # ,
        # widget=widgets.RadioSelect)

        Dem_Pol_View = models.IntegerField(
            choices=[[1, 'conservative'], [2, 'liberal'], [3, 'left']],
            verbose_name='Do you generally consider yourself...',
            widget=widgets.RadioSelect)

        Dem_Gender = models.IntegerField(
            choices=[[0, 'Male'], [1, 'Female'], [2, 'Other']],
            verbose_name='What gender do you identify with?')  # ,
        # widget=widgets.RadioSelect)

        Dem_Nationality = models.StringField(verbose_name='What is your nationality?')

        Dem_Age = models.IntegerField(
            min=0, max=100,
            verbose_name='Please tell us your age:')
    elif Constants.language=='german':
        Dem_Field_of_study = models.StringField(verbose_name='Was ist ihr Studienfach?')

        Dem_Highest_degree = models.IntegerField(
            choices=[[1, 'Sekundarabschluss'], [2, '(Berufs-)Maturität'], [3, 'Lehrabschluss EFZ'],
                     [4, 'Bachelorabschluss'], [5, 'Masterabschluss'], [6, 'Doktoratsabschluss']],
            verbose_name='Was ist Ihr höchster erreichter Bildungsabschluss?')
            #,widget=widgets.RadioSelect)
        ## It should be a dropdown menu that displays the labels but saves the numbers #Leander: If we want a dropdown menu, we don't need to call a widget

        Dem_Party = models.IntegerField(
            choices=[[1, 'SVP'], [2, 'SP'], [3, 'FDP'], [4, 'CVP'], [5, 'Grüne'], [6, 'GLP'],[7, 'BDP'], [8, 'Andere / Ich weiss es nicht']],
            verbose_name='Für welche Partei würden Sie stimmen, falls heute Wahlen wären?')#,
            #widget=widgets.RadioSelect)

        Dem_Pol_View = models.IntegerField(
            choices=[[1, 'conservative'], [2, 'liberal'], [3, 'left'], [0, 'apolitical']],
            verbose_name='Wie würden Sie Ihre polistische Einstellung beschreiben?',
            widget=widgets.RadioSelect)

        Dem_Gender = models.IntegerField(
            choices=[[0, 'männlich'], [1, 'weiblich'], [2, 'andere']],
            verbose_name='Mit welchem Geschlecht identifizieren Sie sich?')

        Dem_Nationality = models.StringField(verbose_name='Bitte geben Sie Ihre Nationalität an:')

        Dem_Age = models.IntegerField(
            min=0, max=100,
            verbose_name='Bitte geben Sie ihr Alter an:')

    # FEEDBACK

    Feedback1_11 = models.FloatField()
    Feedback1_12 = models.LongStringField(blank=True)
    Feedback1_21 = models.FloatField()
    Feedback1_22 = models.LongStringField(blank=True)
    Feedback1_3  = models.IntegerField(blank=True)
    Feedback1_4  = models.FloatField()
    Feedback1_5  = models.FloatField()
    Feedback1_6  = models.LongStringField(blank=True)

    Feedback2_11 = models.FloatField()
    Feedback2_12 = models.LongStringField(blank=True)
    Feedback2_21 = models.FloatField()
    Feedback2_22 = models.LongStringField(blank=True)
    Feedback2_3  = models.FloatField()
    Feedback2_4  = models.FloatField()
    Feedback2_5  = models.LongStringField(blank=True)
    Feedback2_6  = models.LongStringField(blank=True)



    Feedback1 = models.LongStringField(
        verbose_name='If you have any general comments for us please leave them here:',
        blank=True)

    Feedback2 = models.IntegerField(
        choices=[[1, 'Extremely easy'], [2, 'moderately easy'], [3, 'neither easy nor difficult'],
                 [4, 'moderately difficult'], [5, 'extremely difficult']],
        verbose_name='Overall, how easy or difficult was it for you to answer the questions?',
        widget=widgets.RadioSelect)

    Feedback3 = models.FloatField(
        #choices=[[0, 'I did not care at all'], [1, 'Very important']],
        verbose_name='Did you feel as if the choices you made during the experiment were important to you?',
        widget=widgets.Slider(attrs={'step': '0.01'}, show_value=False))

    Feedback4 = models.LongStringField(
        verbose_name='Please briefly describe the choices you made in this experiment in your own words! In this pilot study, we are interested in learning what you perceived your tasks in part 1 and part 2 of this experiment to be.',
        blank=True)
    #Payoff-Variables
    total_payoff = models.FloatField()
    payoff_pre = models.FloatField()
    finalpayoff_part1 = models.FloatField()
    finalpayoff_part2 = models.FloatField()
    finalpayoff_part3 = models.FloatField()
    finalpayoff = models.FloatField()

    #Time-Variables
    time_part3_survey = models.FloatField()
    time_part3_survey_unfocus = models.FloatField()
    time_part3_feedback = models.FloatField()
    time_part3_feedback_unfocus = models.FloatField()

    Qtime = models.FloatField()
    Qfocus = models.FloatField()
    Qunfocus = models.FloatField()
    Qfocusevent = models.FloatField()
